# VTU-CGPA_SGPA-Calculator
---
![Repository Size](https://img.shields.io/github/repo-size/SubramanyaKS/VTU-CGPA_SGPA-Calculator?style=for-the-badge)

This repository contain Java project which calculate CGPA and SGPA of the VTU CBCS Student(2015/2017/2018).


### Technology used:
* Java Swing
* Eclipse IDE

To use the calculator download the jar file and then run on your local machine.For running jar file you require to download java.

If you like this project ⭐the repository.

